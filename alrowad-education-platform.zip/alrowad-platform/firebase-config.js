// ضع إعدادات مشروع Firebase الجديد هنا بعد إنشائه من Firebase Console.
// لا تضع Service Account أو مفاتيح Admin SDK في هذا الملف.
export const firebaseConfig = {
  apiKey: "YOUR_FIREBASE_API_KEY",
  authDomain: "YOUR_PROJECT_ID.firebaseapp.com",
  projectId: "YOUR_PROJECT_ID",
  storageBucket: "YOUR_PROJECT_ID.firebasestorage.app",
  messagingSenderId: "YOUR_MESSAGING_SENDER_ID",
  appId: "YOUR_FIREBASE_APP_ID"
};

export const isFirebaseConfigured = !Object.values(firebaseConfig).some(
  value => typeof value === "string" && value.startsWith("YOUR_")
);