import { firebaseConfig, isFirebaseConfigured } from "./firebase-config.js";

const $ = (s) => document.querySelector(s);
const modal = $("#modalBackdrop"), modalContent = $("#modalContent");
let toastTimer;
function toast(message){const el=$("#toast");el.textContent=message;el.classList.add("show");clearTimeout(toastTimer);toastTimer=setTimeout(()=>el.classList.remove("show"),3200)}
function showModal(html){modalContent.innerHTML=html;modal.hidden=false}
function closeModal(){modal.hidden=true}
$("#year").textContent=new Date().getFullYear();
$("#menuToggle").addEventListener("click",()=>$("#mainNav").classList.toggle("open"));
$("#mainNav").addEventListener("click",e=>{if(e.target.closest("a"))$("#mainNav").classList.remove("open")});
$("#modalClose").addEventListener("click",closeModal);
modal.addEventListener("click",e=>{if(e.target===modal)closeModal()});
$("#loginOpen").addEventListener("click",loginForm);
$("#heroLogin").addEventListener("click",loginForm);
$("#requestOpen").addEventListener("click",requestForm);
document.querySelectorAll("[data-stage]").forEach(btn=>btn.addEventListener("click",()=>{toast(`سيتم عرض محتوى ${btn.dataset.stage} بعد إضافة الصفوف والمناهج من لوحة الإدارة.`)}));

function loginForm(){
 showModal(`<h2 id="modalTitle">تسجيل الدخول</h2><p>أدخل بيانات حسابك للوصول إلى المساحة التعليمية.</p>
 <form id="loginForm"><div class="field"><label>البريد الإلكتروني</label><input type="email" name="email" required autocomplete="username" placeholder="name@example.com"></div>
 <div class="field"><label>كلمة المرور</label><input type="password" name="password" required autocomplete="current-password" minlength="6" placeholder="كلمة المرور"></div>
 <button class="btn btn-primary" type="submit">دخول</button></form>
 <div class="notice">${isFirebaseConfigured?"سيتم التحقق من الحساب عبر Firebase.":"يلزم إعداد مشروع Firebase الخاص بالمنصة أولًا لتفعيل تسجيل الدخول."}</div>`);
 $("#loginForm").addEventListener("submit",async e=>{e.preventDefault();if(!isFirebaseConfigured){toast("أضف إعدادات Firebase في firebase-config.js أولًا.");return}try{const {signInWithEmailAndPassword}=await import("https://www.gstatic.com/firebasejs/11.6.0/firebase-auth.js");const {auth}=await getFirebase();await signInWithEmailAndPassword(auth,e.target.email.value,e.target.password.value);toast("تم تسجيل الدخول بنجاح.");closeModal();await renderDashboard()}catch(err){toast(authError(err))}});
}
function requestForm(){
 showModal(`<h2 id="modalTitle">طلب انضمام</h2><p>أرسل طلبك وسيتم مراجعته من إدارة المنصة.</p>
 <form id="requestForm"><div class="field"><label>الاسم بالكامل</label><input name="name" required maxlength="100"></div>
 <div class="field"><label>البريد الإلكتروني</label><input type="email" name="email" required></div>
 <div class="field"><label>نوع الحساب المطلوب</label><select name="role" required><option value="student">طالب</option><option value="parent">ولي أمر</option><option value="teacher">معلم</option></select></div>
 <div class="field"><label>رقم الهاتف (اختياري)</label><input name="phone" inputmode="tel" maxlength="20"></div>
 <button class="btn btn-primary" type="submit">إرسال الطلب</button></form>
 <div class="notice">إرسال الطلب لا يمنح صلاحية الدخول تلقائيًا. تتم مراجعة الطلب من الإدارة.</div>`);
 $("#requestForm").addEventListener("submit",async e=>{e.preventDefault();if(!isFirebaseConfigured){toast("أضف إعدادات Firebase أولًا لتفعيل إرسال الطلبات.");return}try{const data=Object.fromEntries(new FormData(e.target));const {db}=await getFirebase();const {addDoc,collection,serverTimestamp}=await import("https://www.gstatic.com/firebasejs/11.6.0/firebase-firestore.js");await addDoc(collection(db,"registrationRequests"),{...data,status:"pending",createdAt:serverTimestamp()});toast("تم إرسال الطلب للمراجعة.");closeModal()}catch(err){toast("تعذر إرسال الطلب. تحقق من إعدادات Firebase.");console.error(err)}});
}
let firebasePromise;
function getFirebase(){if(!firebasePromise)firebasePromise=(async()=>{const [{initializeApp,getApps},{getAuth},{getFirestore}]=await Promise.all([import("https://www.gstatic.com/firebasejs/11.6.0/firebase-app.js"),import("https://www.gstatic.com/firebasejs/11.6.0/firebase-auth.js"),import("https://www.gstatic.com/firebasejs/11.6.0/firebase-firestore.js")]);const app=getApps().length?getApps()[0]:initializeApp(firebaseConfig);return{auth:getAuth(app),db:getFirestore(app)}})();return firebasePromise}
function authError(err){const map={"auth/invalid-credential":"بيانات الدخول غير صحيحة.","auth/user-not-found":"الحساب غير موجود.","auth/wrong-password":"كلمة المرور غير صحيحة.","auth/too-many-requests":"محاولات كثيرة. حاول لاحقًا."};return map[err.code]||"تعذر تسجيل الدخول. تحقق من البيانات والإعدادات."}
async function renderDashboard(){
 const main=document.querySelector("main");const {auth,db}=await getFirebase();const user=auth.currentUser;if(!user)return;
 let profile=null;try{const {doc,getDoc}=await import("https://www.gstatic.com/firebasejs/11.6.0/firebase-firestore.js");const snap=await getDoc(doc(db,"users",user.uid));if(snap.exists())profile=snap.data()}catch(e){console.error(e)}
 const role=profile?.role||"pending";const roleNames={owner:"المالك",admin:"المسؤول",teacher:"المعلم",student:"الطالب",parent:"ولي الأمر",pending:"حساب قيد المراجعة"};
 main.innerHTML=`<section class="dashboard"><div class="dash-top"><div><span class="eyebrow">المساحة التعليمية</span><h1>مرحبًا ${escapeHtml(profile?.name||user.email||"بك")}</h1><p>نوع الحساب: ${roleNames[role]||"غير محدد"}</p></div><button class="btn btn-outline" id="logoutBtn">تسجيل الخروج</button></div><div class="dash-grid"><div class="dash-card"><b>—</b><span>الدروس المكتملة</span></div><div class="dash-card"><b>—</b><span>الواجبات</span></div><div class="dash-card"><b>—</b><span>التقدم الدراسي</span></div></div><div class="dash-panel"><h3>${role==="owner"?"لوحة المالك":roleNames[role]||"حالة الحساب"}</h3><div class="empty">${role==="pending"?"حسابك لا يحتوي على دور معتمد بعد. تواصل مع إدارة المنصة لمراجعة طلبك.":"تم تسجيل الدخول. ستظهر هنا وحدات التحكم والبيانات بعد إعداد صلاحيات الحساب وربط محتوى المنصة."}</div></div><div class="notice">هذه نسخة تأسيسية. لا يتم عرض أو تعديل بيانات إدارية قبل إعداد قواعد الأمان وتعيين الصلاحيات من جهة موثوقة.</div></section>`;
 $("#logoutBtn").addEventListener("click",async()=>{await auth.signOut();location.reload()});
}
function escapeHtml(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
